#include <iostream>

void quick_sort(int salary[], int left, int right)
{
    if (left < right)
    {
        int pivot = salary[left];
        int low = left + 1;
        int high = right;

        while (true)
        {
            while (low <= high && salary[low] <= pivot)
            {
                low++;
            }
            while (low <= high && salary[high] > pivot)
            {
                high--;
            }
            if (low <= high)
            {
                std::swap(salary[low], salary[high]);
            }
            else
            {
                break;
            }
        }

        std::swap(salary[left], salary[high]);
        quick_sort(salary, left, high - 1);
        quick_sort(salary, high + 1, right);
    }
}

int main()
{
    int salary[]{30, 2, 10, 43, 21, 12, 17, 19, 90};
    int n = (sizeof(salary)) / (sizeof(int));
    for (int i = 0; i < n; i++)
    {
        std::cout << salary[i] << "\n";
    }
    quick_sort(salary, 0, n - 1);
    for (int i = 0; i < n; i++)
    {
        std::cout << salary[i] << "\n";
    }

    return 0;
}