#include <iostream>
#include <string>
#include <limits>
#include <vector>
#include <algorithm>

void bubble_sort(int salary[], const int n)
{

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (salary[j] > salary[j + 1])
            {
                int t = salary[j];
                salary[j] = salary[j + 1];
                salary[j + 1] = t;
            }
        }
    }
}

int main()
{
    int salary[]{30, 2, 10, 43, 21, 12, 17, 19, 90};
    int n = (sizeof(salary)) / (sizeof(int));
    for (int i = 0; i < n; i++)
    {
        std::cout << salary[i] << "\n";
    }
    bubble_sort(salary, n);
    for (int i = 0; i < n; i++)
    {
        std::cout << salary[i] << "\n";
    }

    return 0;
}
