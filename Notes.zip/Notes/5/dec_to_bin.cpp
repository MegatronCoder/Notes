#include <stack>
#include <iostream>

int main()
{
    std::stack<int> bin_stack;

    int i = 51;
    while (i / 2 != 0)
    {
        bin_stack.push(i % 2);
        i /= 2;
    }

    bin_stack.push(i % 2);

    while (!bin_stack.empty())
    {
        std::cout << bin_stack.top();
        bin_stack.pop();
    }



    return 0;
}
