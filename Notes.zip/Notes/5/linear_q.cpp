#include <iostream>

class queue
{
public:
    int s;
    int f;
    int r;
    int *Q;

public:
    queue() = default;
    ~queue() = default;

public:
    bool isEmpty() const { return f == r ? true : false; }
    bool isFull() const { return r == s - 1 ? true : false; }
    void enqueue()
    {
        if (isFull())
        {
            std::cout << "full"
                      << "\n";
            return;
        }

        r++;
        Q[r] = 10;
    }

    void dequeue()
    {
        if (isEmpty())
        {
            std::cout << "empty"
                      << "\n";
            return;
        }
        f++;
        Q[f] = 0;
    }
};

int main()
{
    queue queue;
    queue.s = 10;
    queue.Q = new int[10]{0};
    queue.r = queue.f = -1;

    for (size_t i = 0; i < 10; i++)
    {
        queue.enqueue();
    }

    for (size_t i = queue.f + 1; i < 10; i++)
    {
        std::cout << queue.Q[i] << "\n";
    }

    for (size_t i = 0; i < 10; i++)
    {
        queue.dequeue();
    }

    std::cout << queue.isEmpty() << "\n";

    delete queue.Q;

    return 0;
}
