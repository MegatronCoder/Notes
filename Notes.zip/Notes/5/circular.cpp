#include <iostream>

class queue
{
public:
    int s;
    int f;
    int r;
    int *Q;
    int a = 0;

public:
    queue() = default;
    ~queue() = default;

public:
    bool isEmpty() const { return f == r ? true : false; }
    bool isFull() const { return (r + 1) % s == f ? true : false; }
    void enqueue()
    {
        if (isFull())
        {
            std::cout << "full"
                      << "\n";
            return;
        }

        r = (r + 1) % s;
        Q[r] = a++;
    }

    void dequeue()
    {
        if (isEmpty())
        {
            std::cout << "empty"
                      << "\n";
            return;
        }
        f = (f + 1) % s;
        Q[f] = 0;
    }

    void display()
    {
        int i = f + 1;
        while (i % s != f)
        {
            std::cout << Q[i] << "\n";
            i = (i + 1) % s;
        }
    }
};

int main()
{
    queue queue;
    queue.s = 5;
    queue.Q = new int[queue.s]{0};
    queue.r = queue.f = 0;

    for (size_t i = 0; i < queue.s - 1; i++)
    {
        queue.enqueue();
    }

    queue.display();

    for (size_t i = 0; i < queue.s; i++)
    {
        queue.dequeue();
    }

    std::cout << queue.isEmpty() << "\n";

    delete queue.Q;

    return 0;
}
