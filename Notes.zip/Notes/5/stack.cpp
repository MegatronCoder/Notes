#include <iostream>
#include <limits>

class Node
{
private:
    int data;
    Node *next;

public:
    Node();
    Node(int d);
    ~Node();

public:
    int getData() const { return data; }
    void putData(int d) { data = d; }
    Node *getNext() const { return next; }
    void putNext(Node *n) { next = n; }
};

Node::Node()
    : data{0}, next{nullptr}
{
}

Node::Node(int d)
    : data{d}, next{nullptr}
{
}

Node::~Node()
{
}

class Stack
{
private:
    Node *top;

public:
    Stack();
    Stack(Node *t);
    ~Stack();

public:
    bool isEmpty() const { return top == nullptr ? true : false; }
    void push()
    {
        int d{};

        std::cout << "\n Enter the Number: ";
        std::cin >> d;
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        Node *n = new Node(d);

        if (isEmpty())
        {
            top = n;
        }

        else
        {
            n->putNext(top);
            top = n;
        }
    }
    void display() const
    {
        if (isEmpty())
        {
            std::cout << "Stack is empty"
                      << "\n";
            return;
        }

        Node *temp = top;

        std::cout << "================" << "\n\n";

        while (temp != nullptr)
        {
            std::cout << temp->getData() << "\n";

            temp = temp->getNext();
        }

        std::cout << "================" << "\n\n";

    }
    int pop()
    {
        if (isEmpty())
        {
            return -1;
        }

        int d = top->getData();
        Node *temp = top;
        top = top->getNext();

        delete temp;
        return d;
    }
    void deleteAll()
    {
        while (pop() != -1)
            ;
    }
    int getTop() const
    {
        if (isEmpty())
        {
            std::cout << "Stack empty"
                      << "\n";
            return -1;
        }

        else
        {
            return top->getData();
        }
    }
    Node *getTopPtr() const
    {
        if (isEmpty())
        {
            std::cout << "Stack empty"
                      << "\n";
        }

        else
        {
            return top;
        }
    }
};

Stack::Stack()
    : top{nullptr}
{
}

Stack::Stack(Node *t)
    : top{t}
{
}

Stack::~Stack()
{
}

void showMenu()
{
    std::cout << "\nPress 1 : Push"
              << "\n";
    std::cout << "Press 2 : Pop"
              << "\n";
    std::cout << "Press 3 : Display"
              << "\n";
    std::cout << "Press 4 : Get top"
              << "\n";
    std::cout << "Press 0 : Quit"
              << "\n";
}

int main()
{
    int choise{};
    int d{};
    Stack *s = new Stack();

    do
    {
        showMenu();
        std::cin >> choise;
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choise)
        {
        case 0:
            break;

        case 1:
            s->push();
            break;

        case 2:
            d = s->pop();
            if (d == -1)
            {
                std::cout << "Stack Empty" << "\n";
            }

            else
            {
                std::cout << d << "\n";
            }


            break;

        case 3:
            s->display();
            break;

        case 4:
            std::cout << s->getTop() << "\n";
            break;

        default:
            std::cout << "Wrong choise"
                      << "\n";
            break;
        }
    } while (choise);

    s->deleteAll();

    return 0;
}
