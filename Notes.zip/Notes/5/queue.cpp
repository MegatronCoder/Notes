#include <iostream>
#include <limits>

class Node
{
private:
    int data;
    Node *next;
    Node *prev;

public:
    Node();
    Node(int d);
    Node(int d, Node *n, Node *p);
    ~Node();

public:
    int getData() const
    {
        return data;
    }
    void putData(int n)
    {
        data = n;
    }

    Node *getNext() const
    {
        return next;
    }
    void putNext(Node *n)
    {
        next = n;
    }
    const Node *readNext() const
    {
        return next;
    }

    Node *getPrev() const
    {
        return prev;
    }
    void putPrev(Node *p)
    {
        prev = p;
    }
    const Node *readPrev() const
    {
        return prev;
    }
};

Node::Node()
    : data{-1}, next{nullptr}, prev{nullptr}
{
}

Node::Node(int d)
    : data{d}, next{nullptr}, prev{nullptr}
{
}
Node::Node(int d, Node *n, Node *p)
    : data{d}, next{n}, prev{p}
{
}

Node::~Node()
{
    std::cout << "deleting"
              << "\n";
}

class Queue
{
private:
    Node *head;
    Node *bottom;

public:
    Queue();
    Queue(Node *h, Node *b);
    ~Queue() = default;

public:
    bool isEmpty() const { return head == nullptr ? true : false; }

    void push()
    {
        int d{};

        std::cout << "\n Enter the Number: ";
        std::cin >> d;
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        Node *n = new Node(d);

        if (isEmpty())
        {
            head = bottom = n;
        }

        else
        {
            head->putPrev(n);
            n->putNext(head);
            head = n;
        }
    }
    int pop()
    {
        if (isEmpty())
        {
            return -1;
        }

        int d = bottom->getData();
        Node *temp = bottom;
        bottom = bottom->getPrev();
        if (bottom != nullptr)
        {
            bottom->putNext(nullptr);
        }
        else
        {
            head = bottom = nullptr; // deleting last node
        }

        delete temp;
        return d;
    }

    void display()
    {
        if (head != nullptr)
        {
            const Node *temp = head;
            while (temp != nullptr)
            {
                std::cout << temp->getData();
                temp = temp->getNext();
            }
        }
    }

    void deleteAll()
    {
        while (pop() != -1)
            ;
    }
};

Queue::Queue()
    : head{nullptr}, bottom{nullptr}
{
}

Queue::Queue(Node *h, Node *b)
    : head{h}, bottom{b}
{
}

void showMenu()
{
    std::cout << "\n ========== MENU ==========";
    std::cout << "\n press 1 to insert: ";
    std::cout << "\n press 2 to pop: ";
    std::cout << "\n press 3 to display: ";

    std::cout << "\n press 0 to quit: ";
}

int main()
{
    Queue Queue;
    int inp{};

    do
    {
        showMenu();
        std::cin >> inp;
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (inp)
        {
        case 0:
            std::cout << "quitting"
                      << "\n";
            Queue.deleteAll();

            break;
        case 1:
            Queue.push();
            break;

         case 2:
            std::cout << Queue.pop() << "\n";
            break;

        case 3:
            Queue.display();
            break;

        default:
            std::cout << "\n wrong choise";
            break;
        }

    } while (inp);

    return 0;
}
