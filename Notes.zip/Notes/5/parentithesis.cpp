#include <stack>
#include <iostream>
#include <string>

bool isParen(const char c)
{
    if (c == '(' || c == '[' || c == '{' || c == ')' || c == ']' || c == '}')
    {
        return true;
    }

    return false;
}
bool isClosing(const char c)
{
    if (c == ')' || c == ']' || c == '}')
    {
        return true;
    }

    return false;
}

bool isRelated(const char stackTop, const char closing)
{
    if (stackTop == '(' && closing == ')')
    {
        return true;
    }

    else if (stackTop == '[' && closing == ']')
    {
        return true;
    }

    else if (stackTop == '{' && closing == '}')
    {
        return true;
    }

    return false;
}

int main()
{
    std::stack<char> exp_stack;
    // stack != empty
    // closing and stack empty
    // bracket at top and closing is not related

    std::string s{};
    std::getline(std::cin, s);

    while (s != "0")
    {
        for (size_t i = 0; i < s.length(); i++)
        {
            if (!isParen(s.at(i)))
            {
                continue;
            }

            if (!isClosing(s.at(i)))
            {
                exp_stack.push(s.at(i));
            }

            else
            {
                if (exp_stack.empty())
                {
                    std::cout << "exp unbalenced"
                              << "\n";
                    break;
                }
                if (!isRelated(exp_stack.top(), s.at(i)))
                {
                    std::cout << "Parenthetis are not related"
                              << "\n";
                    break;
                }

                exp_stack.pop();
            }
        }

        if (!exp_stack.empty())
        {
            std::cout << "exp unbalenced"
                      << "\n";
        }

        while (!exp_stack.empty())
            exp_stack.pop();
        s = "";
        std::getline(std::cin, s);

    }

    return 0;
}
