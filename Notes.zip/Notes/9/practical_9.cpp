#include <iostream>

struct Node {
    int data;
    Node* left;
    Node* right;
    bool isThreaded;

    Node(int value) : data(value), left(nullptr), right(nullptr), isThreaded(false) {}
};

Node* createNode(int value) {
    return new Node(value);
}

void inOrderTraversal(Node* root) {
    Node* current = root;
    while (current) {
        while (current->left) {
            current = current->left;
        }

        std::cout << current->data << " ";

        while (current->isThreaded) {
            current = current->right;
            std::cout << current->data << " ";
        }

        current = current->right;
    }
}

void threadTree(Node* root, Node*& prev) {
    if (!root) {
        return;
    }

    threadTree(root->left, prev);

    if (prev && !prev->right) {
        prev->right = root;
        prev->isThreaded = true;
    }

    prev = root;

    threadTree(root->right, prev);
}

int main() {
    Node* root = createNode(4);
    root->left = createNode(2);
    root->right = createNode(6);
    root->left->left = createNode(1);
    root->left->right = createNode(3);
    root->right->left = createNode(5);
    root->right->right = createNode(7);

    Node* prev = nullptr;
    threadTree(root, prev);

    std::cout << "In-order traversal of the threaded binary tree: ";
    inOrderTraversal(root);
    std::cout << std::endl;

    return 0;
}
