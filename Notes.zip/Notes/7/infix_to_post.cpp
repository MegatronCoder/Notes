#include<iostream>
#include <stack>
#include <string>
#include <vector>


bool isOperator(const char& c)
{
    if (c == '+' || c == '-' || c == '/' || c == '*')
    {
        return true;
    }
    return false;
}

int getPrecedance(const char& c)
{
    if (c == '+' || c == '-')
    {
        return 1;
    }
    return 2;
}


int main()
{
    std::stack<char> postfix_stack{};
    std::string postfix;
    std::string input;

    std::cout << "\nEnter your Exp: " << "\n";
    std::getline(std::cin, input);

    for (size_t i = 0; i < input.length(); i++)
    {
        char curr_char = input.at(i);

        if (isOperator(curr_char))
        {
            // push on stack by checking the precedance
            if (postfix_stack.empty())
            {
                postfix_stack.push(curr_char);
                continue;
            }

            // check precedance:
            if (getPrecedance(curr_char) > getPrecedance(postfix_stack.top()))
            {
                postfix_stack.push(curr_char);
                continue;
            }

            // pop until empty or lower precedance
            while (!postfix_stack.empty() && getPrecedance(postfix_stack.top()) >= getPrecedance(curr_char))
            {
                postfix += postfix_stack.top();
                postfix_stack.pop();
            }

            postfix_stack.push(curr_char);
        }

        else
        {
            postfix += curr_char;
        }


    }

    if (!postfix_stack.empty())
    {
        while (!postfix_stack.empty())
        {
            postfix += postfix_stack.top();
            postfix_stack.pop();
        }

    }

    std::cout << postfix << "\n";

    return 0;
}
