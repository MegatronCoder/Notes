#include <iostream>

struct Node {
    int data;
    Node* left;
    Node* right;
    int height; // Height of the subtree rooted at this node

    Node(int value) : data(value), left(nullptr), right(nullptr), height(1) {}
};

// Function to calculate the height of a node
int getHeight(Node* node) {
    return (node ? node->height : 0);
}

// Function to update the height of a node
void updateHeight(Node* node) {
    node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));
}

// Function to perform a right rotation
Node* rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    updateHeight(y);
    updateHeight(x);

    return x;
}

// Function to perform a left rotation
Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    y->left = x;
    x->right = T2;

    updateHeight(x);
    updateHeight(y);

    return y;
}

// Function to balance the tree
Node* balance(Node* node) {
    if (!node)
        return node;

    int balanceFactor = getHeight(node->left) - getHeight(node->right);

    if (balanceFactor > 1) {
        if (getHeight(node->left->left) >= getHeight(node->left->right))
            return rightRotate(node);
        else {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }
    }
    if (balanceFactor < -1) {
        if (getHeight(node->right->right) >= getHeight(node->right->left))
            return leftRotate(node);
        else {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }
    }

    return node;
}

// Function to insert a node into the BST
Node* insert(Node* root, int value) {
    if (!root)
        return new Node(value);

    if (value < root->data)
        root->left = insert(root->left, value);
    else if (value > root->data)
        root->right = insert(root->right, value);

    updateHeight(root);

    return balance(root);
}

// Function to search for a node in the BST
Node* search(Node* root, int value) {
    if (!root || root->data == value)
        return root;

    if (value < root->data)
        return search(root->left, value);

    return search(root->right, value);
}

// Function to perform an in-order traversal (display in ascending order)
void inOrderTraversal(Node* root) {
    if (!root)
        return;

    inOrderTraversal(root->left);
    std::cout << root->data << " ";
    inOrderTraversal(root->right);
}

int main() {
    Node* root = nullptr;

    root = insert(root, 30);
    root = insert(root, 20);
    root = insert(root, 40);
    root = insert(root, 10);
    root = insert(root, 25);
    root = insert(root, 35);

    std::cout << "In-order traversal of the height-balanced BST: ";
    inOrderTraversal(root);
    std::cout << std::endl;

    int valueToSearch = 25;
    Node* searchResult = search(root, valueToSearch);
    if (searchResult)
        std::cout << "Node with value " << valueToSearch << " found in the BST." << std::endl;
    else
        std::cout << "Node with value " << valueToSearch << " not found in the BST." << std::endl;

    return 0;
}
