#include <iostream>
#include <vector>
#include <algorithm>

// Define a structure to represent an edge in the graph
struct Edge
{
    int src, dest, weight;

    Edge(int source, int destination, int w) : src(source), dest(destination), weight(w) {}
};

// Define a structure to represent a disjoint set (DSU) for cycle detection
struct DSU
{
    std::vector<int> parent, rank;

    DSU(int n)
    {
        parent.resize(n);
        rank.assign(n, 0);
        for (int i = 0; i < n; i++)
        {
            parent[i] = i;
        }
    }

    int findSet(int x)
    {
        if (x != parent[x])
        {
            parent[x] = findSet(parent[x]);
        }
        return parent[x];
    }

    void unionSets(int x, int y)
    {
        int rootX = findSet(x);
        int rootY = findSet(y);

        if (rootX != rootY)
        {
            if (rank[rootX] < rank[rootY])
            {
                parent[rootX] = rootY;
            }
            else if (rank[rootX] > rank[rootY])
            {
                parent[rootY] = rootX;
            }
            else
            {
                parent[rootY] = rootX;
                rank[rootX]++;
            }
        }
    }
};

// Compare function to sort edges by weight
bool compareEdges(const Edge &a, const Edge &b)
{
    return a.weight < b.weight;
}

class Graph
{
public:
    Graph(int vertices);
    void addEdge(int src, int dest, int weight);
    void findMinimumSpanningTree();

private:
    int V; // Number of vertices
    std::vector<Edge> edges;

    // Helper function to print the minimum spanning tree
    void printMST(const std::vector<Edge> &mst);
};

Graph::Graph(int vertices) : V(vertices) {}

void Graph::addEdge(int src, int dest, int weight)
{
    edges.emplace_back(src, dest, weight);
}

void Graph::findMinimumSpanningTree()
{
    std::sort(edges.begin(), edges.end(), compareEdges); // Sort edges by weight
    std::vector<Edge> minimumSpanningTree;
    DSU dsu(V);

    for (const Edge &edge : edges)
    {
        int srcRoot = dsu.findSet(edge.src);
        int destRoot = dsu.findSet(edge.dest);

        if (srcRoot != destRoot)
        {
            minimumSpanningTree.push_back(edge);
            dsu.unionSets(srcRoot, destRoot);
        }
    }

    printMST(minimumSpanningTree);
}

void Graph::printMST(const std::vector<Edge> &mst)
{
    std::cout << "Minimum Spanning Tree (Edges and Weights):" << std::endl;
    for (const Edge &edge : mst)
    {
        std::cout << edge.src << " - " << edge.dest << " : " << edge.weight << std::endl;
    }
}

int main()
{
    int vertices = 5;
    Graph graph(vertices);

    graph.addEdge(0, 1, 2);
    graph.addEdge(0, 3, 6);
    graph.addEdge(1, 2, 3);
    graph.addEdge(1, 3, 8);
    graph.addEdge(1, 4, 5);
    graph.addEdge(2, 4, 7);
    graph.addEdge(3, 4, 9);

    graph.findMinimumSpanningTree();

    return 0;
}
