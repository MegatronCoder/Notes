#include <iostream>
#include <string>
#include <limits>
#include <vector>
#include <algorithm>

int showMenu()
{
    int d;
    std::cout << "Press 1 to search contact linearly"
              << "\n";
    std::cout << "Press 2 to search contact using Binary search"
              << "\n";
    std::cout << "Press 0 quit"
              << "\n";

    std::cin >> d;
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    return d;
}

bool linearSearch(const std::vector<std::string> &contacts, const std::string contact)
{
    for (size_t i = 0; i < contacts.size(); i++)
    {
        if (contact == contacts.at(i))
        {
            return true;
        }
    }

    return false;
}

bool Binsearch(const std::vector<std::string> &contacts, const std::string contact)
{
    std::vector<std::string> contacts_2 = contacts;
    std::sort(contacts_2.begin(), contacts_2.end());
    int low = 0, high = contacts_2.size();

    int mid = (low + high) / 2;

    while (low <= high)
    {
        if (contact == contacts_2[mid])
        {
            return true;
        }

        if (contact > contacts_2[mid])
        {
            low = mid + 1;
        }

        else
        {
            high = high - 1;
        }

        mid = (low + high) / 2;
    }

    return false;
}

int main()
{
    int d;
    std::vector<std::string> contacts{};

    contacts.push_back("123456789");
    contacts.push_back("123456780");
    contacts.push_back("123456789");
    contacts.push_back("123456788");
    contacts.push_back("123456787");
    contacts.push_back("123456786");
    contacts.push_back("123456785");

    std::string contact_str{};

    do
    {
        d = showMenu();
        switch (d)
        {
        case 1:
            std::cout << "Entry contact to search: "
                      << "\n";
            std::getline(std::cin, contact_str);
            std::cout << std::boolalpha << "\n";
            std::cout << linearSearch(contacts, contact_str) << "\n";
            std::cout << std::noboolalpha << "\n";
            break;

        case 2:
            std::cout << "Entry contact to search: "
                      << "\n";
            std::getline(std::cin, contact_str);
            std::cout << std::boolalpha << "\n";
            std::cout << Binsearch(contacts, contact_str) << "\n";
            std::cout << std::noboolalpha << "\n";
            break;

        case 0:
            break;

        default:
            break;
        }
    } while (d != 0);

    return 0;
}
