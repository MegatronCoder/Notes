#include <iostream>
#include <limits>
#include <vector>

void display(const std::vector<std::vector<int>> &vec, int m, int n)
{
    for (size_t i = 0; i < m; i++)
    {
        for (size_t j = 0; j < n; j++)
        {
            std::cout << vec[i][j] << "\n";
        }
    }
}

bool search(const std::vector<std::vector<int>> &vec, int m, int n, int k)
{
    for (size_t i = 0; i < m; i++)
    {
        for (size_t j = 0; j < n; j++)
        {
            if (vec[i][j] == k)
                return true;
        }
    }

    return false;
}

int min(const std::vector<std::vector<int>> &vec, int m, int n)
{
    int min = vec.at(0).at(0);

    for (size_t i = 0; i < m; i++)
    {
        for (size_t j = 0; j < n; j++)
        {
            if (vec[i][j] < min)
                min = vec[i][j];
        }
    }

    return min;
}

int max(const std::vector<std::vector<int>> &vec, int m, int n)
{
    int max = vec.at(0).at(0);

    for (size_t i = 0; i < m; i++)
    {
        for (size_t j = 0; j < n; j++)
        {
            if (vec[i][j] > max)
                max = vec[i][j];
        }
    }

    return max;
}

int main()
{
    const int m{2}, n{2};
    std::vector<std::vector<int>> vec{};
    int inp{};

    for (size_t i = 0; i < m; i++)
    {
        vec.push_back(std::vector<int>());
        for (size_t j = 0; j < n; j++)
        {
            std::cout << "enter ele at: " << i << " " << j << "\n";
            std::cin >> inp;
            vec.at(i).push_back(inp);
        }
    }

    display(vec, m, n);
    std::cout << std::boolalpha;
    std::cout << search(vec , m , n , 3) << "\n";;
    std::cout << std::noboolalpha;

    std::cout << min(vec , m , n) << "\n";
    std::cout << max(vec , m , n) << "\n";


    return 0;
}
