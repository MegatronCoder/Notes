#include <iostream>
#include <string>
#include <limits>
#include <bitset>
#include <algorithm>
#include <map>

class Node
{
private:
    int data;
    Node *next;
    Node *prev;

public:
    Node();
    Node(int d);
    Node(int d, Node *n, Node *p);
    ~Node();

public:
    int getData() const
    {
        return data;
    }
    void putData(int n)
    {
        data = n;
    }

    Node *getNext() const
    {
        return next;
    }
    void putNext(Node *n)
    {
        next = n;
    }
    const Node *readNext() const
    {
        return next;
    }

    Node *getPrev() const
    {
        return prev;
    }
    void putPrev(Node *p)
    {
        prev = p;
    }
    const Node *readPrev() const
    {
        return prev;
    }
};

Node::Node()
    : data{-1}, next{nullptr}, prev{nullptr}
{
}

Node::Node(int d)
    : data{d}, next{nullptr}, prev{nullptr}
{
}
Node::Node(int d, Node *n, Node *p)
    : data{d}, next{n}, prev{p}
{
}

Node::~Node()
{
    std::cout << "deleting"
              << "\n";
}

class DDL
{
private:
    Node *head;
    Node *last;

public:
    DDL();
    DDL(Node *h, Node *l);
    ~DDL() = default;

public:
    void insert()
    {
        if (head != nullptr)
        {
            std::cout << "\n already number stored";
            return;
        }

        std::string bin_no{};
        std::cout << "Enter the a bin number: "
                  << "\n";
        std::getline(std::cin, bin_no);

        if (check_input(bin_no))
        {
            Node *n = new Node(convert(bin_no.at(0)));
            head = n;
            Node *temp{n};

            for (int i = 1; i < bin_no.length(); i++)
            {
                n = new Node(convert(bin_no.at(i)));
                temp->putNext(n);
                n->putPrev(temp);
                temp = n;
            }

            last = temp;
        }

        else
        {
            std::cout << "\n\n Going back to menu: ";
        }
    }
    void display()
    {
        if (head != nullptr)
        {
            const Node *temp = head;
            while (temp != nullptr)
            {
                std::cout << temp->getData();
                temp = temp->getNext();
            }
        }
    }

    void delete_node()
    {
        if (head != nullptr)
        {
            Node *temp = head;
            Node *n = temp->getNext();

            while (temp != nullptr)
            {
                delete temp;
                temp = n;
                if (n != nullptr)
                {
                    n = n->getNext();
                }
            }
        }
    }
    // utils
public:
    bool check_input(const std::string &s) const
    {
        if (s.length() % 4 != 0)
        {
            std::cout
                << "\n please represent digit in four bits."
                << "\n you entered a "
                << s.length()
                << " bit no.";

            return false;
        }

        for (auto &i : s)
        {
            if (std::isdigit(i) == 0)
            {
                std::cout
                    << "\n You have entered a wrong pattern"
                    << "\n please enter correct bin number"
                    << "\n You entered " << s;

                return false;
            }
        }

        return true;
    }

    int convert(const char &c) const
    {
        if (c == '0')
        {
            return 0;
        }
        return 1;
    }

    char convert(const int &c) const
    {
        if (c == 0)
        {
            return '0';
        }
        return '1';
    }

    int flip(const int &d) const
    {
        if (d == 0)
        {
            return 1;
        }

        return 0;
    }

    void ones_complement() const
    {
        if (head != nullptr)
        {
            const Node *temp = head;
            std::string s{};
            while (temp != nullptr)
            {
                s += convert(flip(temp->getData()));
                temp = temp->getNext();
            }
            std::cout << s << "\n";
        }
    }
    void twos_complement() const
    {
        if (head != nullptr)
        {
            const Node *temp = last;
            std::string s{};
            bool first_one_flag = false;
            while (temp != nullptr)
            {
                if (!first_one_flag && temp->getData() != 1)
                {
                    s += convert(temp->getData());
                }
                else
                {
                    if (!first_one_flag)
                    {
                        s += convert(temp->getData());
                        first_one_flag = true;
                    }
                    else
                    {
                        s += convert(flip(temp->getData()));
                    }
                }

                temp = temp->getPrev();
            }
            std::reverse(s.begin(), s.end());
            std::cout << s << "\n";
        }
    }

    int generateCarry(const int &res) const
    {
        if (res == 1)
        {
            return 0;
        }
        else if (res >= 2)
        {
            return 1;
        }

        return 0;
    }
    char generateSum(const int &res) const
    {
        if (res == 2 || res == 0)
        {
            return '0';
        }
        else
        {
            return '1';
        }
    }

    void coverRemainingBits(Node *rev, std::string &out, int &res, int &carry) const
    {
        while (rev != nullptr)
        {
            res = rev->getData() + carry;
            carry = generateCarry(res);

            out += generateSum(res);

            res = 0;
            rev = rev->getPrev();
        }
    }
    void add() const
    {
        std::string bin_no1{};
        std::cout << "Enter the 1st bin number: "
                  << "\n";
        std::getline(std::cin, bin_no1);

        std::string bin_no2{};
        std::cout << "Enter the 2nd bin number: "
                  << "\n";
        std::getline(std::cin, bin_no2);

        if (check_input(bin_no1) && check_input(bin_no2))
        {
            Node *n = new Node(convert(bin_no1.at(0)));
            Node *n2 = new Node(convert(bin_no2.at(0)));

            Node *temp{n};
            Node *temp2{n2};

            for (int i = 1; i < bin_no1.length(); i++)
            {
                n = new Node(convert(bin_no1.at(i)));
                temp->putNext(n);
                n->putPrev(temp);
                temp = n;
            }

            for (int i = 1; i < bin_no2.length(); i++)
            {
                n2 = new Node(convert(bin_no2.at(i)));
                temp2->putNext(n2);
                n2->putPrev(temp2);
                temp2 = n2;
            }

            Node *rev1 = temp;
            Node *rev2 = temp2;

            int res = 0;
            std::string out{};
            int carry = 0;

            while (rev1 != nullptr && rev2 != nullptr)
            {
                res = rev1->getData() + rev2->getData() + carry;

                carry = generateCarry(res);
                out += generateSum(res);

                res = 0;

                rev1 = rev1->getPrev();
                rev2 = rev2->getPrev();
            }

            if (rev1 == nullptr && rev2 == nullptr)
            {
                out += convert(carry);
            }

            else if (rev1 != nullptr)
            {
                coverRemainingBits(rev1, out, res, carry);
            }

            else
            {
                coverRemainingBits(rev2, out, res, carry);
            }

            std::reverse(out.begin(), out.end());
            std::cout << out << "\n";
        }
    }
};

// 110011

DDL::DDL()
    : head{nullptr}, last{nullptr}
{
}

DDL::DDL(Node *h, Node *l)
    : head{h}, last{l}
{
}

int main()
{
    DDL ddl;
    int inp{5};

    do
    {
        std::cout << "\n ========== MENU ==========";
        std::cout << "\n press 1 to insert: ";
        std::cout << "\n press 2 to display: ";
        std::cout << "\n press 3 to 1's complement: ";
        std::cout << "\n press 4 to 2's complement: ";
        std::cout << "\n press 5 to add two no.: ";

        std::cout << "\n press 0 to quit: \n\n\n";

        std::cin >> inp;
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (inp)
        {
        case 0:
            std::cout << "quitting"
                      << "\n";
            ddl.delete_node();

            break;
        case 1:
            ddl.insert();
            break;

        case 2:
            ddl.display();
            break;

        case 3:
            ddl.ones_complement();
            break;
        case 4:
            ddl.twos_complement();
            break;

        case 5:
            ddl.add();
            break;

        default:
            std::cout << "\n wrong choise";
            break;
        }

    } while (inp != 0);

    return 0;
}
