#include <iostream>
#include <string>
#include <unordered_map>

struct Employee
{
    int id;
    std::string name;
    std::string department;

    Employee(int emp_id, const std::string &emp_name, const std::string &emp_department)
        : id(emp_id), name(emp_name), department(emp_department) {}

    Employee() = default;
};

int main()
{
    std::unordered_map<int, Employee> employeeDatabase;

    employeeDatabase[1001] = Employee(1001, "John Doe", "HR");
    employeeDatabase[1002] = Employee(1002, "Jane Smith", "Engineering");
    employeeDatabase[1003] = Employee(1003, "Bob Johnson", "Finance");

    int lookupId = 1002;
    if (employeeDatabase.find(lookupId) != employeeDatabase.end())
    {
        ;
        std::cout << "Employee ID: " << employeeDatabase[lookupId].id << std::endl;
        std::cout << "Name: " << employeeDatabase[lookupId].name << std::endl;
        std::cout << "Department: " << employeeDatabase[lookupId].department << std::endl;
    }
    else
    {
        std::cout << "Employee with ID " << lookupId << " not found in the database." << std::endl;
    }

    lookupId = 1001;
    if (employeeDatabase.find(lookupId) != employeeDatabase.end())
    {
        ;
        std::cout << "Employee ID: " << employeeDatabase[lookupId].id << std::endl;
        std::cout << "Name: " << employeeDatabase[lookupId].name << std::endl;
        std::cout << "Department: " << employeeDatabase[lookupId].department << std::endl;
    }
    else
    {
        std::cout << "Employee with ID " << lookupId << " not found in the database." << std::endl;
    }


    lookupId = 1003;
    if (employeeDatabase.find(lookupId) != employeeDatabase.end())
    {
        ;
        std::cout << "Employee ID: " << employeeDatabase[lookupId].id << std::endl;
        std::cout << "Name: " << employeeDatabase[lookupId].name << std::endl;
        std::cout << "Department: " << employeeDatabase[lookupId].department << std::endl;
    }
    else
    {
        std::cout << "Employee with ID " << lookupId << " not found in the database." << std::endl;
    }


    return 0;
}


// def insertion():
//     for i in range(len(arr)):
//         key = arr[i]
//         j = i - 1
//         while j >= 0 and arr[j] > key:
//             arr[j + 1] = arr[j]
//             j = j - 1

//         arr[j + 1] = key