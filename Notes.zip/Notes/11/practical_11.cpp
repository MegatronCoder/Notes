#include <iostream>
#include <vector>
#include <queue>
#include <stack>

class Graph {
public:
    Graph(int vertices);

    void addEdge(int from, int to);
    void BFS(int startVertex);
    void DFS(int startVertex);

private:
    int vertices;
    std::vector<std::vector<int>> adjacencyList;
};

Graph::Graph(int vertices) {
    this->vertices = vertices;
    adjacencyList.resize(vertices);
}

void Graph::addEdge(int from, int to) {
    adjacencyList[from].push_back(to);
}

void Graph::BFS(int startVertex) {
    std::vector<bool> visited(vertices, false);
    std::queue<int> queue;

    visited[startVertex] = true;
    queue.push(startVertex);

    while (!queue.empty()) {
        int currentVertex = queue.front();
        std::cout << currentVertex << " ";
        queue.pop();

        for (int neighbor : adjacencyList[currentVertex]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                queue.push(neighbor);
            }
        }
    }

    std::cout << std::endl;
}

void Graph::DFS(int startVertex) {
    std::vector<bool> visited(vertices, false);
    std::stack<int> stack;

    stack.push(startVertex);

    while (!stack.empty()) {
        int currentVertex = stack.top();
        stack.pop();

        if (!visited[currentVertex]) {
            std::cout << currentVertex << " ";
            visited[currentVertex] = true;
        }

        for (int neighbor : adjacencyList[currentVertex]) {
            if (!visited[neighbor]) {
                stack.push(neighbor);
            }
        }
    }

    std::cout << std::endl;
}

int main() {
    Graph graph(6);

    graph.addEdge(0, 1);
    graph.addEdge(0, 2);
    graph.addEdge(1, 3);
    graph.addEdge(1, 4);
    graph.addEdge(2, 4);
    graph.addEdge(3, 5);
    graph.addEdge(4, 5);

    std::cout << "Breadth-First Search (BFS): ";
    graph.BFS(0);

    std::cout << "Depth-First Search (DFS): ";
    graph.DFS(0);

    return 0;
}
