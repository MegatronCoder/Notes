#include <iostream>
#include <limits>

class Node
{
private:
    int data;
    Node *next;

public:
    Node();
    Node(int d);
    ~Node();

public:
    int getData() const { return data; }
    void putData(int d) { data = d; }
    Node *getNext() const { return next; }
    void putNext(Node *n) { next = n; }
};

Node::Node()
    : data{0}, next{nullptr}
{
}

Node::Node(int d)
    : data{d}, next{nullptr}
{
}

Node::~Node()
{
}

class CLL
{
private:
    Node *head;

public:
    CLL();
    CLL(Node *t);
    ~CLL();

public:
    bool isEmpty() const { return head == nullptr ? true : false; }
    int take_input(std::string msg) const
    {
        int d{};

        std::cout << "\n"
                  << msg;
        std::cin >> d;
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        return d;
    }
    bool search(int d) const
    {
        if (head->getData() == d)
        {
            return true;
        }

        Node *t = head->getNext();
        bool flag = false;

        while (t != head)
        {
            if (t->getData() == d)
            {
                flag = true;
                break;
            }

            t = t->getNext();
        }
        return flag;
    }
    void insert()
    {
        int d = take_input("Enter a number to insert: ");

        Node *n = new Node(d);

        if (isEmpty())
        {
            head = n;
            head->putNext(head);
        }

        else
        {
            Node *t = head;
            while (t->getNext() != head)
                t = t->getNext();

            t->putNext(n);
            n->putNext(head);
        }
    }
    void display() const
    {
        if (isEmpty())
        {
            std::cout << "CLL is empty"
                      << "\n";
            return;
        }

        Node *temp = head->getNext();

        std::cout << "================"
                  << "\n\n";

        std::cout << head->getData() << "\n";

        while (temp != head)
        {
            std::cout << temp->getData() << "\n";

            temp = temp->getNext();
        }

        std::cout << "================"
                  << "\n\n";
    }
    int delete_node()
    {
        if (isEmpty())
        {
            return -1;
        }

        int d = take_input("Enter a number to delete: ");

        if (!search(d))
        {
            return -2;
        }

        Node *temp = head;
        Node *n = temp->getNext();
        if (head->getData() == d)
        {
            while (temp->getNext() != head)
                temp = temp->getNext();

            if (temp == head)
            {
                delete head;
                head = nullptr;
                return d;
            }

            delete head;
            head = temp;
            temp->putNext(head);
            return d;
        }

        while (n->getData() != d)
        {
            temp = n;
            n = n->getNext();
        }

        Node *next = n->getNext();

        if (n->getNext() == head)
        {
            next = head;
        }

        temp->putNext(next);
        delete n;
        return d;
    }
    void delete_all()
    {
        if (isEmpty())
        {
            return;
        }

        Node *n = head->getNext();
        Node *t = nullptr;
        while (n != head)
        {
            t = n;
            n = n->getNext();
            delete t;
        }

        delete head;
    }

public:
    int gethead() const
    {
        if (isEmpty())
        {
            std::cout << "CLL empty"
                      << "\n";
            return -1;
        }

        else
        {
            return head->getData();
        }
    }
    Node *getheadPtr() const
    {
        if (isEmpty())
        {
            std::cout << "CLL empty"
                      << "\n";
        }

        else
        {
            return head;
        }
    }
};

CLL::CLL()
    : head{nullptr}
{
}

CLL::CLL(Node *t)
    : head{t}
{
}

CLL::~CLL()
{
}

void showMenu()
{
    std::cout << "\nPress 1 : Insert"
              << "\n";
    std::cout << "Press 2 : Delete"
              << "\n";
    std::cout << "Press 3 : Display"
              << "\n";
    std::cout << "Press 4 : search"
              << "\n";
    std::cout << "Press 0 : Quit"
              << "\n";
}

int main()
{
    int choise{};
    int d{};
    CLL *s = new CLL();

    do
    {
        showMenu();
        std::cin >> choise;
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choise)
        {
        case 0:
            break;

        case 1:
            s->insert();
            break;

        case 2:
            d = s->delete_node();
            if (d == -1)
            {
                std::cout << "list Empty"
                          << "\n";
            }
            else if (d == -2)
            {
                std::cout << "Ele not in list"
                          << "\n";
            }

            else
            {
                std::cout << d << "\n";
            }

            break;

        case 3:
            s->display();
            break;

        case 4:
            d = s->take_input("Enter a number to search: ");
            std::cout << std::boolalpha;
            std::cout << s->search(d) << "\n";
            std::cout << std::noboolalpha;
            break;

        default:
            std::cout << "Wrong choise"
                      << "\n";
            break;
        }
    } while (choise);

    s->delete_all();
    return 0;
}