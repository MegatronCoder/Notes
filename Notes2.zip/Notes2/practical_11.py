import pandas as pd
from scipy import stats
# Load the Pima Indians Diabetes dataset (modify the file path accordingly)
data = pd.read_csv("diabetes.csv")
# Define the significance level (alpha)
alpha = 0.05
def perform_t_test(diabetic_group, non_diabetic_group):
 t_statistic, t_p_value = stats.ttest_ind(diabetic_group, non_diabetic_group)
 return t_statistic, t_p_value
def perform_z_test(diabetic_group, non_diabetic_group):
 z_statistic = stats.zscore(diabetic_group)
 z_p_value = stats.zscore(non_diabetic_group)
 return z_statistic.mean(), z_p_value.mean()
def perform_chi_square_test(diabetic_group, non_diabetic_group):
 observed_data = [len(diabetic_group), len(non_diabetic_group)]
 expected_data = [len(data) * 0.5, len(data) * 0.5] # Assumingequal proportions
 chi2, p_value = stats.chisquare(f_obs=observed_data,f_exp=expected_data)
 return chi2, p_value
while True:
 print("Choose a test to perform:")
 print("1. T-test")
 print("2. Z-test")
 print("3. Chi-square test")
 print("4. Quit")
 choice = input("Enter your choice (1/2/3/4): ")
 if choice == '1':
    diabetic_group = data[data['Outcome'] == 1]['Glucose']
    non_diabetic_group = data[data['Outcome'] == 0]['Glucose']
    t_statistic, t_p_value = perform_t_test(diabetic_group,
    non_diabetic_group)
    print("T-test results:")
    print(f'T-statistic: {t_statistic}')
    print(f'P-value: {t_p_value}')
 if t_p_value < alpha:
    print("Reject the null hypothesis (t-test): There is asignificant difference between the groups.")
 else:
    print("Fail to reject the null hypothesis (t-test): There is no significant difference between the groups.")
 elif choice == '2':
 diabetic_group = data[data['Outcome'] == 1]['Glucose']
 non_diabetic_group = data[data['Outcome'] == 0]['Glucose']
 z_statistic, z_p_value = perform_z_test(diabetic_group,non_diabetic_group)
 print("Z-test results:")
 print(f'Z-statistic (diabetic group): {z_statistic}')
 print(f'Z-statistic (non-diabetic group): {z_p_value}')
 if z_p_value < alpha:
    print("Reject the null hypothesis (Z-test): There is a significant difference between the groups.")
 else:
    print("Fail to reject the null hypothesis (Z-test): There is no significant difference between the groups.")
 elif choice == '3':
 diabetic_group = data[data['Outcome'] == 1]['Glucose']
 non_diabetic_group = data[data['Outcome'] == 0]['Glucose']
 chi2, chi2_p_value = perform_chi_square_test(diabetic_group,non_diabetic_group)
 print("Chi-square test results:")
 print(f'Chi-squared statistic: {chi2}')
 print(f'P-value: {chi2_p_value}')
 if chi2_p_value < alpha:
    print("Reject the null hypothesis (Chi-square test): Thereis a significant difference between the groups.")
 else:
    print("Fail to reject the null hypothesis (Chi-square test):There is no significant difference between the groups.")
 elif choice == '4':
    break
 else:
    print("Invalid choice. Please choose a valid option(1/2/3/4).")
